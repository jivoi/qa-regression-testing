<?php

$_SERVER["PATH_INFO"] = "/scrape";
require("tracker.php");
exit;

?>