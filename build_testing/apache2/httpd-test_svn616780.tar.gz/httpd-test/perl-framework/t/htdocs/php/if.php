<?php $a=1; if($a>0) { echo "Yes"; } ?>
