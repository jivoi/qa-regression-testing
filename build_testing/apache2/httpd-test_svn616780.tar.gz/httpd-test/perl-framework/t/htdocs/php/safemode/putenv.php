<?php putenv("FOO_BAR=HelloWorld");
echo getenv("FOO_BAR"); ?>
