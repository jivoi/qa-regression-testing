<?php $a=27; $b=7; $c=10; $d=$a-$b-$c; echo $d?>
