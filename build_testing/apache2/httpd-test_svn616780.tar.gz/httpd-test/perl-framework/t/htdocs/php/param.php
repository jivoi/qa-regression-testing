<?php  old_function Test $a,$b (
                echo $a+$b;
        );
        Test(1,2)?>

