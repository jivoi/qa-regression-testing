<?php echo getenv("REQUEST_METHOD"); ?>
