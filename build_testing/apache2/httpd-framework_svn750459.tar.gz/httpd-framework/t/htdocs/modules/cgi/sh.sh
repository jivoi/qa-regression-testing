#!/bin/sh
echo Content-type: text/plain
echo
echo sh cgi
