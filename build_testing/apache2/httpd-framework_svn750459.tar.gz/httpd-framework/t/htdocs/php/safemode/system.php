<?php system("printf HelloWorld"); ?>

