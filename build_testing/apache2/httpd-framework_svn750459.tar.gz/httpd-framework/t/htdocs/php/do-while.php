<?php 
$i=3;
do {
	echo $i;
	$i--;
} while($i>0);
?>
