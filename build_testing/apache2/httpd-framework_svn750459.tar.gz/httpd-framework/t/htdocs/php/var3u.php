<?php echo "$V1 $V2 $V3"?>
